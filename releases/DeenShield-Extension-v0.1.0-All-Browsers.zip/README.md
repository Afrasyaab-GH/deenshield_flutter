# Deen Shield – Stay Focused, Browse Safely, Live by Your Values

[![Chrome Web Store](https://img.shields.io/badge/Chrome-Web%20Store-brightgreen)](https://chrome.google.com/webstore)
[![Firefox Add-ons](https://img.shields.io/badge/Firefox-Add--ons-orange)](https://addons.mozilla.org/firefox)
[![Edge Add-ons](https://img.shields.io/badge/Edge-Add--ons-blue)](https://microsoftedge.microsoft.com/addons)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> ☪️ **Your complete Islamic browsing companion - Protection, Productivity, and Spiritual Growth**

**Developed by [Alhaq Initiative](https://alhaq-initiative.org)** - A specialized Islamic technology organization dedicated to creating digital solutions that align with Islamic values and serve the Muslim community worldwide.

## 🌟 What is Deen Shield?

**Deen Shield** is a powerful browser extension that helps Muslims stay productive and protect their faith online. It blocks haram and harmful content, reduces distractions, and provides an optional **Islamic new-tab experience (DeenHub)** with Qur'an verses, authentic adhkaar, and prayer times — right when you start your browsing.

Perfect for students, professionals, and families who want to browse with peace of mind and align their online experience with Islamic values.

## ✨ Why Install Deen Shield?

**Deen Shield offers:**

✅ **Faith-aligned protection** – Automatically filters categories like gambling, riba/interest, adult content, and more harmful websites

✅ **Stay focused** – Reduce social media and time-wasting sites so you can use your time wisely and productively

✅ **Personal control** – Add your own custom blocklists, keywords, and domain filters for tailored discipline

✅ **Daily spiritual boost** – Replace your new tab with **DeenHub**: Qur'an verses with recitation, authentic adhkaar from Hisnul Muslim, live prayer times, and Islamic wellness features

✅ **Advanced blur protection** – Intelligent content blurring to shield you from inappropriate images across all websites

✅ **Simple & private** – Works completely locally on your device, with no tracking, no data collection, and no external servers

✅ **Secure & protected** – Optional password lock to prevent unauthorized changes to your settings

## 🎯 Key Features

### 🛡️ **Smart Content Blocking**
- **Haram Content Filter**: Automatically blocks inappropriate websites and adult content with 10,000+ domain database
- **Social Media Control**: Optional blocking of major social platforms (Facebook, Instagram, Twitter, TikTok, etc.) to reduce distractions
- **Custom Keywords & Domains**: Add your own keywords, terms, and website domains to block for personalized discipline
- **Real-time Protection**: Instant blocking as you browse with declarative net request rules
- **Safe Search Enforcement**: Automatically enables strict safe search on Google, Bing, DuckDuckGo, and Yahoo

### ☪️ **DeenHub - Islamic New Tab Experience**
- **Daily Qur'an Verses**: Beautiful Arabic text with English translation and audio recitation from multiple reciters
- **Authentic Adhkaar**: 60+ authentic remembrances from Hisnul Muslim with Arabic text, transliteration, translation, and hadith references
- **Dhikr Counter**: Interactive counter with progress tracking, celebration animations, and keyboard shortcuts
- **Live Prayer Times**: Automatic location-based Salah times using Aladhan API with multiple calculation methods
- **Wellness Features**: Break reminders, health tips, and spiritual guidance
- **Customizable**: Toggle DeenHub on/off, choose reciters, adjust prayer calculation methods, and customize your experience

### 🎨 **Advanced Blur Protection**
- **Intelligent Image Blurring**: Automatically blurs potentially inappropriate images using keyword detection
- **Manual Blur Control**: Select and blur specific elements on any webpage
- **Keyboard Shortcuts**: Quick toggle blur with Alt+L, blur selected elements with Alt+K
- **Performance Optimized**: Efficient CSS-based blurring without impacting page load times

### 🔐 **Security & Privacy**
- **Password Protection**: Secure your settings with password lock to prevent unauthorized changes
- **Local Storage Only**: All data stays on your device - no external servers, no cloud sync
- **Zero Tracking**: We don't collect, analyze, or transmit any personal data or browsing history
- **Encrypted Settings**: All preferences are securely stored using browser's native storage API
- **Open Source**: Fully transparent code available for audit on GitHub

### ?? **Cross-Browser Support**
- ? **Chrome** (v88+)
- ? **Microsoft Edge** (v88+)
- ? **Firefox** (v109+)
- ? **Opera, Brave, Vivaldi** (Chromium-based)

### ?? **Professional Interface**
- Clean, intuitive design following modern UI principles
- Islamic-themed colors and aesthetics
- Responsive layout that works on all screen sizes
- Accessibility-compliant for all users

## ?? Installation

### Chrome Web Store
```
?? Available on Chrome Web Store
Search for "Deen Shield" or visit the direct link
```

### Firefox Add-ons (AMO)
```
?? Available on Firefox Add-ons
Search for "Deen Shield" in Firefox Add-ons Manager
```

### Edge Add-ons
```
?? Available on Microsoft Edge Add-ons
Search for "Deen Shield" in Edge Add-ons store
```

### Manual Installation (Developer Mode)
1. Download the latest release from our [GitHub Releases](https://github.com/HabibGHub/DeenShield-Extension/releases)
2. Extract the ZIP file
3. Open your browser's extension page
4. Enable "Developer mode"
5. Click "Load unpacked" and select the extracted folder

## 🚀 Quick Start

1. **Install** the extension from your browser's web store
2. **Click** the Deen Shield icon in your browser toolbar
3. **Configure** your blocking preferences:
   - Toggle Haram content blocking (recommended: ON)
   - Toggle Social media blocking (optional)
   - Add custom keywords and domains you want to block
   - Enable blur protection for images
4. **Set** a password to protect your settings (optional but recommended)
5. **Open a new tab** to experience **DeenHub** - your Islamic home page with:
   - Daily Qur'an verses with recitation
   - Authentic adhkaar and dhikr counter
   - Live prayer times for your location
   - Islamic wellness features
6. **Customize DeenHub** by clicking the settings button (⚙️) to:
   - Choose your favorite Qur'an reciter
   - Set your location for accurate prayer times
   - Select prayer calculation method and madhab
   - Toggle DeenHub on/off if preferred
7. **Browse** with confidence knowing you're protected and spiritually connected!

## ⚙️ Advanced Configuration

### Content Blocking Options

| Feature | Description | Default |
|---------|-------------|---------|
| **Haram Content** | Blocks inappropriate websites and adult content | ✅ Enabled |
| **Social Media** | Blocks major social platforms | ❌ Disabled |
| **Custom Keywords** | User-defined terms to block | Empty list |
| **Custom Domains** | User-defined websites to block | Empty list |
| **Blur Protection** | Blurs potentially inappropriate images | ✅ Enabled |
| **Safe Search** | Enforces strict safe search on search engines | ✅ Enabled |

### DeenHub Configuration

| Feature | Description | Options |
|---------|-------------|---------|
| **Qur'an Reciter** | Audio recitation voice | 10+ reciters including Abdul Basit, Mishary Alafasy, Saad Al-Ghamdi |
| **Prayer Calculation** | Method for Salah times | MWL, ISNA, Karachi, Umm Al-Qura, Egyptian |
| **Madhab (Asr)** | School of thought for Asr time | Shafi/Maliki/Hanbali, Hanafi |
| **Location** | City for prayer times | Manual entry or browser geolocation |
| **Background Style** | Visual theme | Default gradient, Pattern, Light, Dark, Custom color, Image |

### Password Protection
- Protects extension settings from unauthorized changes
- Uses secure local encryption
- No password recovery - keep it safe!

### Keyboard Shortcuts
- **Alt+L**: Toggle blur on/off globally
- **Alt+K**: Blur selected element on any webpage
- **Space**: Increment dhikr counter (when DeenHub is open)

## ?? Privacy & Security

### What We DON'T Do
- ? We don't track your browsing
- ? We don't collect personal data
- ? We don't send data to external servers
- ? We don't show ads or sponsored content

### What We DO
- ? Store settings locally on your device
- ? Encrypt all sensitive data
- ? Provide complete transparency
- ? Follow Islamic principles in development

## ?? Browser Compatibility

| Browser | Version | Manifest | Status |
|---------|---------|----------|---------|
| Chrome | 88+ | V3 | ? Fully Supported |
| Edge | 88+ | V3 | ? Fully Supported |
| Firefox | 109+ | V2 | ? Fully Supported |
| Opera | Latest | V3 | ? Supported |
| Brave | Latest | V3 | ? Supported |

## ?? About Alhaq Digital Services (ADS)

**Alhaq Digital Services** is a pioneering Islamic technology company committed to developing digital solutions that uphold Islamic values and serve the global Muslim community. Our mission is to create technology that promotes what is good (Ma'ruf) and prevents what is harmful (Munkar) in the digital space.

### Our Vision
To be the leading provider of Islamic-compliant digital solutions that help Muslims maintain their faith while navigating the modern digital world.

### Our Values
- **Islamic Principles**: All our products follow Islamic guidelines
- **Privacy First**: We respect user privacy and data protection
- **Community Service**: Serving the Ummah is our primary goal
- **Quality Excellence**: Professional, reliable, and secure solutions
- **Transparency**: Open and honest in all our practices

### Company Information
- **Website**: [https://alhaq-initiative.org](https://alhaq-initiative.org)
- **Contact**: [Contact Page](https://alhaq-initiative.org/contact.html)
- **Industry**: Islamic Technology Solutions
- **Focus**: Digital solutions aligned with Islamic values

## ?? Contributing

We welcome contributions from the Muslim developer community!

### Development Setup
```bash
# Clone the repository
git clone https://github.com/HabibGHub/DeenShield-Extension.git
cd deen-shield-extension

# Install dependencies
npm install

# Build for all browsers
npm run build

# Test in Firefox
npm run test:firefox

# Refresh the packaged adult blocklist from upstream sources
npm run blocklist:update
```

### Blocklist Maintenance

- The extension ships with a curated halal-safe baseline of adult domains in `data/blocklists/adult-domains.json`.
- Run `npm run blocklist:update` periodically to pull the latest pornographic and explicit domain feeds from trusted open-source blocklists.
- After updating, commit the regenerated JSON so the packaged extension stays aligned with the latest datasets. Rebuild (`npm run build:all`) before distributing to ensure the refreshed list is bundled for every browser.

### Code Standards
- Follow Islamic principles in all development
- Maintain user privacy and security
- Write clean, documented code
- Test across all supported browsers

## ?? License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## ?? Support the Project

If Deen Shield has helped you maintain better Islamic browsing habits:

- ? **Star** this repository
- ?? **Share** with your Muslim friends and family
- ?? **Report** any issues you find
- ?? **Suggest** new features
- ?? **Make Dua** for the Alhaq Digital Services team

## ?? Support & Contact

### Technical Support
- ?? **Email**: support@alhaq-initiative.org
- ?? **Bug Reports**: [GitHub Issues](https://github.com/HabibGHub/DeenShield-Extension/issues)
- ?? **Feature Requests**: [GitHub Discussions](https://github.com/HabibGHub/DeenShield-Extension/discussions)

### Company Contact
- ?? **Company**: Alhaq Digital Services (ADS)
- ?? **Website**: https://alhaq-initiative.org
- ?? **Contact**: https://alhaq-initiative.org/contact.html
- ?? **Business**: info@alhaq-initiative.org

### Community
- ?? **Documentation**: Available on our website
- ?? **Tutorials**: Coming soon on our platform

## 📋 Changelog

### Version 1.7.0 (November 6, 2025) - **Major Feature Release**
- ☪️ **DeenHub - Islamic New Tab**: Complete Islamic home tab experience with Qur'an, adhkaar, and prayer times
- 📿 **Authentic Adhkaar Collection**: 60+ authentic dhikr from Hisnul Muslim with Arabic, transliteration, translation, and hadith references
- 🎨 **Modern Islamic Design**: Futuristic glassmorphism UI with Islamic color palette (emerald, gold, teal)
- 🕌 **Enhanced Prayer Times**: Live Salah times with multiple calculation methods and madhab support
- 🎯 **Dhikr Counter**: Interactive counter with progress bars, celebration animations, and keyboard shortcuts (Space bar)
- 📖 **Qur'an Recitation**: Multiple reciter support with audio playback and fullscreen mode
- 🎭 **Advanced Blur Protection**: Intelligent content blurring with manual selection and keyboard shortcuts (Alt+L, Alt+K)
- 🎨 **Improved Floating Buttons**: Modern glassmorphism FABs with tooltips, entrance animations, and notification badges
- 📚 **Comprehensive User Guide**: Detailed in-app guide with all features and Islamic guidance
- 🔧 **Build System Improvements**: Fixed file copying issues and automated distribution packaging
- ⚡ **Performance Optimizations**: Enhanced background script efficiency and reduced memory footprint

### Version 1.2.0 (August 2, 2025)
- 🛡️ **Save Changes Pattern**: Eliminated crashes from rapid toggling with batched settings updates
- ⚡ **Enhanced Stability**: Robust error handling and race condition prevention
- 🎨 **Improved UX**: Clear visual indicators for unsaved changes and saving status
- 🔧 **Technical Improvements**: Fixed Chrome API unique ID errors and async handling
- 🚀 **Performance**: Optimized background script execution and memory usage

### Version 1.1.0 (July 25, 2025)
- 🌐 **Cross-Browser Enhancement**: Improved compatibility across all supported browsers
- 🔒 **Advanced Blocking Logic**: Enhanced domain matching and keyword filtering
- 🔧 **Bug Fixes**: Resolved toggle state inconsistencies and storage sync issues
- 📱 **UI Refinements**: Polished interface elements and responsive design improvements

### Version 1.0.0 (July 20, 2025) - **Initial Release**
- 🎉 **First Public Release**: Professional launch by Alhaq Digital Services
- 🌍 **Cross-Browser Support**: Chrome, Firefox, Edge compatibility
- 🛡️ **Haram Content Blocking**: Comprehensive inappropriate content filtering
- 📱 **Social Media Control**: Optional blocking of major social platforms
- 🔐 **Password Protection**: Secure settings with authentication system
- 🎨 **Professional UI**: Clean, Islamic-themed interface design
- 🔒 **Privacy First**: Complete local storage with zero data collection

## ?? Islamic Compliance

This extension is developed by Alhaq Digital Services following Islamic principles:
- **Halal Development**: Clean code and ethical practices
- **Privacy Respect**: No surveillance or data collection
- **Community Benefit**: Helping the Ummah maintain good habits
- **Transparency**: Open source and auditable code
- **Amanah**: Trustworthy and reliable service

## ?? Testimonials

> *"Deen Shield by Alhaq Digital Services has completely transformed my browsing experience. I can focus on beneficial content without worrying about stumbling upon inappropriate material."*  
> **- Ahmad K., Software Engineer**

> *"As a parent, I feel much more confident letting my teenagers use the internet with Deen Shield installed. Alhaq Digital Services has created something truly valuable for Muslim families."*  
> **- Fatima M., Mother of 3**

> *"The password protection feature is genius. It prevents me from disabling the blocker during moments of weakness. JazakAllahu khair to the ADS team!"*  
> **- Yusuf A., University Student**

---

<div align="center">

**"And whoever fears Allah - He will make for him a way out"** - *Quran 65:2*

Made with ?? by **Alhaq Digital Services (ADS)** for the Muslim Ummah

[?? Website](https://alhaq-initiative.org) � [?? Contact](https://alhaq-initiative.org/contact.html) � [?? GitHub](https://github.com/HabibGHub/DeenShield-Extension)

</div>