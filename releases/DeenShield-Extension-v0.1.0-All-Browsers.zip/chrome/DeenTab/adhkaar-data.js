/**
 * Authentic Adhkaar Collection
 * Source: Hisnul Muslim (Fortress of the Muslim)
 * Compiled from authentic Hadith collections
 */

const ADHKAAR_COLLECTION = {
  // Morning Adhkaar (أذكار الصباح)
  morning: [
    {
      id: 'ayat-kursi',
      arabic: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ',
      transliteration: 'Allāhu lā ilāha illā huwa al-ḥayyu al-qayyūm. Lā ta\'khudhuhu sinatun wa lā nawm. Lahu mā fī as-samāwāti wa mā fī al-arḍ...',
      translation: 'Allah - there is no deity except Him, the Ever-Living, the Sustainer of existence. Neither drowsiness overtakes Him nor sleep...',
      reference: 'Al-Baqarah 2:255',
      count: 1,
      category: 'morning'
    },
    {
      id: 'qul-huwa-allahu-ahad',
      arabic: 'قُلْ هُوَ اللَّهُ أَحَدٌ • اللَّهُ الصَّمَدُ • لَمْ يَلِدْ وَلَمْ يُولَدْ • وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ',
      transliteration: 'Qul huwa Allāhu aḥad. Allāhu aṣ-ṣamad. Lam yalid wa lam yūlad. Wa lam yakun lahu kufuwan aḥad.',
      translation: 'Say: He is Allah, the One. Allah, the Eternal Refuge. He neither begets nor is born. Nor is there to Him any equivalent.',
      reference: 'Surah Al-Ikhlas (112)',
      count: 3,
      category: 'morning'
    },
    {
      id: 'qul-aoudhu-bi-rabbil-falaq',
      arabic: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ • مِن شَرِّ مَا خَلَقَ • وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ • وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ • وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ',
      transliteration: 'Qul aʿūdhu bi-rabbi al-falaq. Min sharri mā khalaq. Wa min sharri ghāsiqin idhā waqab. Wa min sharri an-naffāthāti fī al-ʿuqad. Wa min sharri ḥāsidin idhā ḥasad.',
      translation: 'Say: I seek refuge in the Lord of daybreak, from the evil of that which He created, from the evil of darkness when it settles, from the evil of the blowers in knots, and from the evil of an envier when he envies.',
      reference: 'Surah Al-Falaq (113)',
      count: 3,
      category: 'morning'
    },
    {
      id: 'qul-aoudhu-bi-rabbin-nas',
      arabic: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ • مَلِكِ النَّاسِ • إِلَٰهِ النَّاسِ • مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ • الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ • مِنَ الْجِنَّةِ وَالنَّاسِ',
      transliteration: 'Qul aʿūdhu bi-rabbi an-nās. Maliki an-nās. Ilāhi an-nās. Min sharri al-waswāsi al-khannās. Alladhī yuwaswisu fī ṣudūri an-nās. Min al-jinnati wa an-nās.',
      translation: 'Say: I seek refuge in the Lord of mankind, the Sovereign of mankind, the God of mankind, from the evil of the retreating whisperer, who whispers in the breasts of mankind, from among the jinn and mankind.',
      reference: 'Surah An-Nas (114)',
      count: 3,
      category: 'morning'
    },
    {
      id: 'morning-dua-1',
      arabic: 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ',
      transliteration: 'Aṣbaḥnā wa aṣbaḥa al-mulku lillāh, wa al-ḥamdu lillāh, lā ilāha illā Allāhu waḥdahu lā sharīka lah, lahu al-mulku wa lahu al-ḥamdu wa huwa ʿalā kulli shay\'in qadīr.',
      translation: 'We have entered morning and the dominion belongs to Allah, and all praise is to Allah. None has the right to be worshipped but Allah alone, Who has no partner. To Him belongs the dominion, and to Him is all praise, and He is Able to do all things.',
      reference: 'Muslim 4/2088',
      count: 1,
      category: 'morning'
    },
    {
      id: 'morning-protection',
      arabic: 'بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ',
      transliteration: 'Bismillāhi alladhī lā yaḍurru maʿa ismihi shay\'un fī al-arḍi wa lā fī as-samā\'i wa huwa as-samīʿu al-ʿalīm.',
      translation: 'In the Name of Allah, with Whose Name nothing can harm in the earth or in the heaven, and He is the All-Hearing, the All-Knowing.',
      reference: 'Abu Dawud 4/323, At-Tirmidhi 5/465',
      count: 3,
      category: 'morning'
    }
  ],

  // Evening Adhkaar (أذكار المساء)
  evening: [
    {
      id: 'evening-dua-1',
      arabic: 'أَمْسَيْنَا وَأَمْسَىٰ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ',
      transliteration: 'Amsaynā wa amsā al-mulku lillāh, wa al-ḥamdu lillāh, lā ilāha illā Allāhu waḥdahu lā sharīka lah, lahu al-mulku wa lahu al-ḥamdu wa huwa ʿalā kulli shay\'in qadīr.',
      translation: 'We have entered evening and the dominion belongs to Allah, and all praise is to Allah. None has the right to be worshipped but Allah alone, Who has no partner. To Him belongs the dominion, and to Him is all praise, and He is Able to do all things.',
      reference: 'Muslim 4/2088',
      count: 1,
      category: 'evening'
    }
  ],

  // After Prayer Adhkaar (أذكار بعد الصلاة)
  afterPrayer: [
    {
      id: 'istighfar',
      arabic: 'أَسْتَغْفِرُ اللَّهَ',
      transliteration: 'Astaghfiru Allāh',
      translation: 'I seek forgiveness from Allah',
      reference: 'Muslim 1/414',
      count: 3,
      category: 'after-prayer'
    },
    {
      id: 'after-prayer-dua',
      arabic: 'اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ',
      transliteration: 'Allāhumma anta as-salāmu wa minka as-salām, tabārakta yā dhā al-jalāli wa al-ikrām.',
      translation: 'O Allah, You are Peace and from You comes peace. Blessed are You, O Owner of majesty and honor.',
      reference: 'Muslim 1/414',
      count: 1,
      category: 'after-prayer'
    },
    {
      id: 'tasbih-33',
      arabic: 'سُبْحَانَ اللَّهِ',
      transliteration: 'Subḥān Allāh',
      translation: 'Glory be to Allah',
      reference: 'Al-Bukhari 1/255, Muslim 1/418',
      count: 33,
      category: 'after-prayer'
    },
    {
      id: 'tahmid-33',
      arabic: 'الْحَمْدُ لِلَّهِ',
      transliteration: 'Al-ḥamdu lillāh',
      translation: 'All praise is to Allah',
      reference: 'Al-Bukhari 1/255, Muslim 1/418',
      count: 33,
      category: 'after-prayer'
    },
    {
      id: 'takbir-34',
      arabic: 'اللَّهُ أَكْبَرُ',
      transliteration: 'Allāhu akbar',
      translation: 'Allah is the Greatest',
      reference: 'Al-Bukhari 1/255, Muslim 1/418',
      count: 34,
      category: 'after-prayer'
    },
    {
      id: 'tahlil-100',
      arabic: 'لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ',
      transliteration: 'Lā ilāha illā Allāhu waḥdahu lā sharīka lah, lahu al-mulku wa lahu al-ḥamdu wa huwa ʿalā kulli shay\'in qadīr.',
      translation: 'None has the right to be worshipped but Allah alone, Who has no partner. To Him belongs the dominion, and to Him is all praise, and He is Able to do all things.',
      reference: 'Al-Bukhari 1/255, Muslim 1/418',
      count: 1,
      category: 'after-prayer'
    }
  ],

  // Before Sleep Adhkaar (أذكار النوم)
  beforeSleep: [
    {
      id: 'sleep-ayat-kursi',
      arabic: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ...',
      transliteration: 'Allāhu lā ilāha illā huwa al-ḥayyu al-qayyūm...',
      translation: 'Ayat al-Kursi (The Throne Verse)',
      reference: 'Al-Baqarah 2:255',
      count: 1,
      category: 'before-sleep'
    },
    {
      id: 'sleep-protection',
      arabic: 'بِاسْمِكَ رَبِّي وَضَعْتُ جَنْبِي وَبِكَ أَرْفَعُهُ، إِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا، وَإِنْ أَرْسَلْتَهَا فَاحْفَظْهَا بِمَا تَحْفَظُ بِهِ عِبَادَكَ الصَّالِحِينَ',
      transliteration: 'Bismika rabbī waḍaʿtu janbī wa bika arfaʿuh, in amsakta nafsī fa-irḥamhā, wa in arsaltahā fa-iḥfaẓhā bimā taḥfaẓu bihi ʿibādaka aṣ-ṣāliḥīn.',
      translation: 'In Your Name, my Lord, I lie down and in Your Name I rise. If You take my soul, have mercy on it, and if You send it back, protect it as You protect Your righteous servants.',
      reference: 'Al-Bukhari 11/126, Muslim 4/2084',
      count: 1,
      category: 'before-sleep'
    }
  ],

  // General Dhikr (الأذكار العامة)
  general: [
    {
      id: 'subhanallah',
      arabic: 'سُبْحَانَ اللَّهِ',
      transliteration: 'Subḥān Allāh',
      translation: 'Glory be to Allah',
      reference: 'General dhikr',
      count: 33,
      category: 'general'
    },
    {
      id: 'subhanallah-wa-bihamdihi',
      arabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
      transliteration: 'Subḥān Allāhi wa bi-ḥamdih',
      translation: 'Glory be to Allah and praise Him',
      reference: 'Al-Bukhari 7/168, Muslim 4/2071',
      count: 100,
      category: 'general'
    },
    {
      id: 'subhanallah-al-azim',
      arabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
      transliteration: 'Subḥān Allāhi wa bi-ḥamdih, subḥān Allāhi al-ʿaẓīm',
      translation: 'Glory be to Allah and praise Him, Glory be to Allah the Almighty',
      reference: 'Al-Bukhari 7/168, Muslim 4/2072',
      count: 10,
      category: 'general'
    },
    {
      id: 'alhamdulillah',
      arabic: 'الْحَمْدُ لِلَّهِ',
      transliteration: 'Al-ḥamdu lillāh',
      translation: 'All praise is to Allah',
      reference: 'General dhikr',
      count: 33,
      category: 'general'
    },
    {
      id: 'allahu-akbar',
      arabic: 'اللَّهُ أَكْبَرُ',
      transliteration: 'Allāhu akbar',
      translation: 'Allah is the Greatest',
      reference: 'General dhikr',
      count: 34,
      category: 'general'
    },
    {
      id: 'la-ilaha-illa-allah',
      arabic: 'لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ',
      transliteration: 'Lā ilāha illā Allāhu waḥdahu lā sharīka lah, lahu al-mulku wa lahu al-ḥamdu wa huwa ʿalā kulli shay\'in qadīr',
      translation: 'None has the right to be worshipped but Allah alone, Who has no partner. To Him belongs the dominion, and to Him is all praise, and He is Able to do all things',
      reference: 'Al-Bukhari, Muslim',
      count: 10,
      category: 'general'
    },
    {
      id: 'istighfar-full',
      arabic: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ',
      transliteration: 'Astaghfiru Allāha wa atūbu ilayh',
      translation: 'I seek forgiveness from Allah and repent to Him',
      reference: 'Al-Bukhari',
      count: 100,
      category: 'general'
    },
    {
      id: 'sayyid-istighfar',
      arabic: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَٰهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَىٰ عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ',
      transliteration: 'Allāhumma anta rabbī lā ilāha illā ant, khalaqtanī wa anā ʿabduk, wa anā ʿalā ʿahdika wa waʿdika mā istaṭaʿt, aʿūdhu bika min sharri mā ṣanaʿt, abū\'u laka bi-niʿmatika ʿalayy, wa abū\'u bi-dhanbī fa-ighfir lī, fa-innahu lā yaghfiru adh-dhunūba illā ant',
      translation: 'O Allah, You are my Lord. None has the right to be worshipped but You. You created me and I am Your servant. I abide by Your covenant and promise as best I can. I seek refuge in You from the evil of what I have done. I acknowledge Your favor upon me and I acknowledge my sin. So forgive me, for verily none forgives sins except You.',
      reference: 'Al-Bukhari 7/150',
      count: 1,
      category: 'general'
    },
    {
      id: 'salawat',
      arabic: 'اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَعَلَىٰ آلِ مُحَمَّدٍ، كَمَا صَلَّيْتَ عَلَىٰ إِبْرَاهِيمَ وَعَلَىٰ آلِ إِبْرَاهِيمَ، إِنَّكَ حَمِيدٌ مَجِيدٌ',
      transliteration: 'Allāhumma ṣalli ʿalā Muḥammadin wa ʿalā āli Muḥammad, kamā ṣallayta ʿalā Ibrāhīma wa ʿalā āli Ibrāhīm, innaka ḥamīdun majīd',
      translation: 'O Allah, send prayers upon Muhammad and the family of Muhammad, as You sent prayers upon Ibrahim and the family of Ibrahim. Verily, You are Praiseworthy and Glorious.',
      reference: 'Al-Bukhari 6/151',
      count: 10,
      category: 'general'
    }
  ],

  // Quick categories for easy access
  categories: {
    morning: { name: 'Morning Adhkaar', nameAr: 'أذكار الصباح', icon: '🌅' },
    evening: { name: 'Evening Adhkaar', nameAr: 'أذكار المساء', icon: '🌙' },
    afterPrayer: { name: 'After Prayer', nameAr: 'بعد الصلاة', icon: '🤲' },
    beforeSleep: { name: 'Before Sleep', nameAr: 'أذكار النوم', icon: '😴' },
    general: { name: 'General Dhikr', nameAr: 'الأذكار العامة', icon: '📿' }
  }
};

// Export for use in deen-tab.js
if (typeof window !== 'undefined') {
  window.ADHKAAR_COLLECTION = ADHKAAR_COLLECTION;
}
