/**
 * AI Content Analyzer - NSFWJS Integration
 * Real-time image and content analysis for Deen Shield
 * Uses TensorFlow.js and NSFWJS for client-side ML inference
 */

(function() {
    'use strict';
    
    // Browser API compatibility
    const browserAPI = (typeof browser !== 'undefined') ? browser : (typeof chrome !== 'undefined' ? chrome : null);
    
    if (!browserAPI || !browserAPI.storage) {
        console.warn('⚠️ Browser storage API not available, AI protection disabled');
        return;
    }

    // Configuration
    const CONFIG = {
        ENABLED: false, // Will be set from settings
        MODEL_URL: 'https://cdn.jsdelivr.net/npm/nsfwjs@2.4.2/dist/',
        THRESHOLDS: {
            porn: 0.5,      // Block if >50% confidence
            sexy: 0.7,      // Block if >70% confidence
            hentai: 0.5,    // Block if >50% confidence
            drawing: 0.9    // Only block explicit drawings
        },
        AGGRESSIVE_MODE: false, // Stricter thresholds
        SCAN_DELAY: 500,        // ms delay before scanning new images
        MAX_IMAGE_SIZE: 1000,   // Max width/height for analysis (performance)
        WHITELIST_DOMAINS: [
            'quran.com',
            'islamqa.info',
            'islamweb.net',
            'seekersguidance.org',
            'bayyinah.com',
            'yaqeeninstitute.org',
            'muslimmatters.org',
            'islamic-relief.org'
        ]
    };

    // State
    let model = null;
    let isModelLoading = false;
    let modelLoadFailed = false;
    let processedImages = new WeakSet();
    let analysisQueue = [];
    let isProcessing = false;
    let observer = null;

    /**
     * Check if AI protection is enabled from settings
     * AI protection is the BASE layer - works even if all other blocks are off
     * Only disabled if explicitly turned off
     */
    async function isAIProtectionEnabled() {
        try {
            const result = await browserAPI.storage.sync.get('settings');
            const settings = result.settings || {};
            
            // AI Protection is ON by default unless explicitly disabled
            // It's the base layer that works independently of other toggles
            if (settings.aiProtection === false) {
                return false; // Explicitly disabled
            }
            
            // If any protection mode is active, AI is definitely on
            if (settings.islamicMode === 'strict' || 
                settings.islamicMode === 'full' || 
                settings.islamicMode === 'flexible-mode') {
                return true;
            }
            
            // Default: AI protection is ALWAYS ON unless explicitly disabled
            // This is the base layer - works even when all block toggles are off
            return settings.aiProtection !== false;
            
        } catch (e) {
            console.warn('Failed to check AI protection settings:', e);
            // Default to ON for safety
            return true;
        }
    }

    /**
     * Check if current domain is whitelisted (Islamic sites)
     */
    function isWhitelistedDomain() {
        const hostname = window.location.hostname.toLowerCase();
        return CONFIG.WHITELIST_DOMAINS.some(domain => 
            hostname === domain || hostname.endsWith('.' + domain)
        );
    }

    /**
     * Check if NSFWJS model is ready (in MAIN world)
     */
    let modelReady = false;
    let pendingRequests = new Map();
    let requestIdCounter = 0;
    
    // Listen for messages from MAIN world
    window.addEventListener('message', (event) => {
        if (event.source !== window) return;
        
        const data = event.data;
        
        if (data.type === 'NSFWJS_MODEL_READY') {
            console.log('✅ NSFWJS model ready in MAIN world');
            modelReady = true;
            modelLoadFailed = false;
            isModelLoading = false;
        }
        
        if (data.type === 'NSFWJS_MODEL_FAILED' || data.type === 'NSFWJS_LOAD_FAILED') {
            console.error('❌ NSFWJS model failed to load in MAIN world');
            modelLoadFailed = true;
            isModelLoading = false;
            modelReady = false;
        }
        
        if (data.type === 'NSFWJS_ANALYSIS_RESULT') {
            const callback = pendingRequests.get(data.requestId);
            if (callback) {
                callback({ success: true, predictions: data.predictions });
                pendingRequests.delete(data.requestId);
            }
        }
        
        if (data.type === 'NSFWJS_ANALYSIS_ERROR') {
            const callback = pendingRequests.get(data.requestId);
            if (callback) {
                callback({ success: false, error: data.error });
                pendingRequests.delete(data.requestId);
            }
        }
    });
    
    /**
     * Wait for model to be ready
     */
    async function waitForModel() {
        if (modelReady) return true;
        if (modelLoadFailed) return false;
        
        isModelLoading = true;
        
        // Wait up to 10 seconds for model
        const maxWait = 10000;
        const startTime = Date.now();
        
        while (!modelReady && !modelLoadFailed && (Date.now() - startTime) < maxWait) {
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        
        isModelLoading = false;
        return modelReady;
    }
    
    /**
     * Convert image to data URL
     */
    function imageToDataURL(img) {
        try {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            
            // Resize if too large
            let width = img.naturalWidth || img.width;
            let height = img.naturalHeight || img.height;
            
            if (width > CONFIG.MAX_IMAGE_SIZE || height > CONFIG.MAX_IMAGE_SIZE) {
                const ratio = Math.min(CONFIG.MAX_IMAGE_SIZE / width, CONFIG.MAX_IMAGE_SIZE / height);
                width = Math.floor(width * ratio);
                height = Math.floor(height * ratio);
            }
            
            canvas.width = width;
            canvas.height = height;
            ctx.drawImage(img, 0, 0, width, height);
            
            return canvas.toDataURL('image/jpeg', 0.8);
        } catch (error) {
            console.warn('⚠️ Failed to convert image to data URL:', error);
            return null;
        }
    }
    
    /**
     * Analyze image by sending to MAIN world
     */
    async function analyzeImageViaMainWorld(dataURL) {
        return new Promise((resolve) => {
            const requestId = requestIdCounter++;
            const timeout = setTimeout(() => {
                pendingRequests.delete(requestId);
                resolve({ success: false, error: 'timeout' });
            }, 30000); // 30 second timeout
            
            pendingRequests.set(requestId, (result) => {
                clearTimeout(timeout);
                resolve(result);
            });
            
            window.postMessage({
                type: 'NSFWJS_ANALYZE_REQUEST',
                requestId: requestId,
                dataURL: dataURL
            }, '*');
        });
    }

    /**
     * Analyze an image element
     */
    async function analyzeImage(img) {
        // Skip if already processed
        if (processedImages.has(img)) {
            return { blocked: false, reason: 'already_processed' };
        }

        // Skip if too small (likely icon/button)
        if (img.width < 50 || img.height < 50) {
            processedImages.add(img);
            return { blocked: false, reason: 'too_small' };
        }

        // Skip if image not loaded
        if (!img.complete || img.naturalWidth === 0) {
            return { blocked: false, reason: 'not_loaded' };
        }

        // Wait for model to be ready
        const isReady = await waitForModel();
        if (!isReady) {
            return { blocked: false, reason: 'model_unavailable' };
        }

        try {
            // Convert image to data URL
            const dataURL = imageToDataURL(img);
            if (!dataURL) {
                processedImages.add(img);
                return { blocked: false, reason: 'conversion_failed' };
            }
            
            // Send to MAIN world for analysis
            const result = await analyzeImageViaMainWorld(dataURL);
            
            if (!result.success) {
                processedImages.add(img);
                return { blocked: false, reason: 'analysis_error' };
            }
            
            const predictions = result.predictions;
            
            // Log predictions for debugging
            console.log('🔍 Image analysis:', {
                src: img.src.substring(0, 100),
                predictions: predictions.map(p => ({
                    class: p.className,
                    confidence: (p.probability * 100).toFixed(1) + '%'
                }))
            });

            // Check against thresholds
            const thresholds = CONFIG.AGGRESSIVE_MODE ? {
                porn: 0.3,
                sexy: 0.5,
                hentai: 0.3,
                drawing: 0.7
            } : CONFIG.THRESHOLDS;

            for (const prediction of predictions) {
                const className = prediction.className.toLowerCase();
                const probability = prediction.probability;

                if (className === 'porn' && probability > thresholds.porn) {
                    return { 
                        blocked: true, 
                        reason: 'porn_detected',
                        confidence: (probability * 100).toFixed(1) + '%'
                    };
                }
                if (className === 'sexy' && probability > thresholds.sexy) {
                    return { 
                        blocked: true, 
                        reason: 'sexy_content',
                        confidence: (probability * 100).toFixed(1) + '%'
                    };
                }
                if (className === 'hentai' && probability > thresholds.hentai) {
                    return { 
                        blocked: true, 
                        reason: 'hentai_detected',
                        confidence: (probability * 100).toFixed(1) + '%'
                    };
                }
            }

            // Mark as processed
            processedImages.add(img);
            return { blocked: false, reason: 'safe' };

        } catch (error) {
            console.warn('⚠️ Image analysis error:', error);
            processedImages.add(img);
            return { blocked: false, reason: 'analysis_error' };
        }
    }

    /**
     * Block/hide an image element
     */
    function blockImage(img, reason) {
        try {
            // Check if already blocked by other Deen Shield features
            if (img.classList && img.classList.contains('deenshield-blocked')) {
                return; // Already blocked, don't duplicate
            }
            
            // Mark as AI blocked
            img.classList.add('deenshield-ai-blocked');
            img.classList.add('deenshield-blocked');
            
            // Hide the image
            img.style.display = 'none';
            img.style.visibility = 'hidden';
            
            // Create replacement div
            const replacement = document.createElement('div');
            replacement.className = 'deenshield-ai-blocked-placeholder';
            replacement.style.cssText = `
                width: ${img.width || 200}px;
                height: ${img.height || 150}px;
                min-width: 100px;
                min-height: 100px;
                background: linear-gradient(135deg, #174a3c 0%, #1e3a8a 100%);
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-family: system-ui, -apple-system, sans-serif;
                font-size: 14px;
                text-align: center;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            `;
            replacement.innerHTML = `
                <div>
                    <div style="font-size: 32px; margin-bottom: 10px;">🛡️</div>
                    <div style="font-weight: 600;">Content Blocked by AI</div>
                    <div style="font-size: 12px; opacity: 0.8; margin-top: 5px;">
                        ${reason.reason.replace(/_/g, ' ')} (${reason.confidence || 'High'})
                    </div>
                </div>
            `;

            // Insert replacement
            if (img.parentNode) {
                img.parentNode.insertBefore(replacement, img);
            }

            console.log('🚫 AI blocked image:', reason);
        } catch (error) {
            console.warn('⚠️ Error blocking image:', error);
        }
    }

    /**
     * Process image queue
     */
    async function processQueue() {
        if (isProcessing || analysisQueue.length === 0) return;
        
        isProcessing = true;
        
        try {
            while (analysisQueue.length > 0) {
                const img = analysisQueue.shift();
                
                // Skip if removed from DOM
                if (!document.contains(img)) continue;
                
                try {
                    const result = await analyzeImage(img);
                    
                    if (result.blocked) {
                        blockImage(img, result);
                    }
                } catch (imgError) {
                    console.warn('⚠️ Error analyzing image:', imgError);
                    // Continue processing other images
                }
                
                // Small delay between analyses for performance
                await new Promise(resolve => setTimeout(resolve, 50));
            }
        } catch (error) {
            console.error('❌ Queue processing error:', error);
        } finally {
            isProcessing = false;
        }
    }

    /**
     * Queue an image for analysis
     */
    function queueImage(img) {
        if (!analysisQueue.includes(img) && !processedImages.has(img)) {
            analysisQueue.push(img);
            
            // Debounce queue processing
            setTimeout(() => {
                if (!isProcessing) {
                    processQueue();
                }
            }, CONFIG.SCAN_DELAY);
        }
    }

    /**
     * Scan all images on page
     */
    function scanAllImages() {
        const images = document.querySelectorAll('img');
        images.forEach(img => queueImage(img));
    }

    /**
     * Setup mutation observer to watch for new images
     */
    function setupObserver() {
        try {
            if (observer) {
                observer.disconnect();
            }

            observer = new MutationObserver((mutations) => {
                try {
                    for (const mutation of mutations) {
                        // Check added nodes
                        for (const node of mutation.addedNodes) {
                            if (node.nodeType === Node.ELEMENT_NODE) {
                                try {
                                    // Direct image
                                    if (node.tagName === 'IMG') {
                                        queueImage(node);
                                    }
                                    // Images in subtree
                                    else if (node.querySelectorAll) {
                                        const images = node.querySelectorAll('img');
                                        images.forEach(img => queueImage(img));
                                    }
                                } catch (nodeError) {
                                    // Skip problematic nodes
                                }
                            }
                        }
                    }
                } catch (mutationError) {
                    console.warn('⚠️ Mutation observer error:', mutationError);
                }
            });

            if (document.body) {
                observer.observe(document.body, {
                    childList: true,
                    subtree: true
                });

                console.log('👀 AI content monitoring active (Base Layer)');
            }
        } catch (error) {
            console.error('❌ Failed to setup observer:', error);
        }
    }

    /**
     * Initialize AI protection
     */
    async function initialize() {
        try {
            // Check if whitelisted
            if (isWhitelistedDomain()) {
                console.log('✅ Islamic site detected - AI protection disabled');
                return;
            }

            // Check if enabled in settings
            const enabled = await isAIProtectionEnabled();
            if (!enabled) {
                console.log('ℹ️ AI protection disabled in settings');
                return;
            }

            console.log('🚀 Initializing AI content protection (Base Layer)...');
            CONFIG.ENABLED = true;

        // Check if aggressive mode
        try {
            const result = await browserAPI.storage.sync.get('settings');
            const settings = result.settings || {};
            CONFIG.AGGRESSIVE_MODE = settings.aggressiveBlur === true || settings.islamicMode === 'strict' || settings.islamicMode === 'full';
        } catch (e) {}

        // Wait for model to load in MAIN world, then start scanning
        waitForModel().then((isReady) => {
            if (isReady) {
                // Scan existing images
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', scanAllImages);
                } else {
                    scanAllImages();
                }

                // Setup observer for dynamic content
                if (document.body) {
                    setupObserver();
                } else {
                    document.addEventListener('DOMContentLoaded', setupObserver);
                }
            } else {
                console.warn('⚠️ AI model not available, image scanning disabled');
            }
        });
        } catch (error) {
            console.error('❌ AI protection initialization failed:', error);
            CONFIG.ENABLED = false;
        }
    }

    /**
     * Listen for settings changes
     */
    if (browserAPI && browserAPI.storage && browserAPI.storage.onChanged) {
        browserAPI.storage.onChanged.addListener((changes, areaName) => {
            if (areaName === 'sync' && changes.settings) {
                const newSettings = changes.settings.newValue || {};
                const enabled = newSettings.aiProtection === true || 
                              newSettings.islamicMode === 'strict' || 
                              newSettings.islamicMode === 'full' ||
                              newSettings.islamicMode === 'flexible-mode';
                
                if (enabled && !CONFIG.ENABLED) {
                    initialize();
                } else if (!enabled && CONFIG.ENABLED) {
                    CONFIG.ENABLED = false;
                    if (observer) {
                        observer.disconnect();
                        observer = null;
                    }
                    console.log('🛑 AI protection disabled');
                }
            }
        });
    }

    // Initialize on load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }

})();
