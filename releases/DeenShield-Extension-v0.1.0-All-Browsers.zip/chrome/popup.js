document.addEventListener('DOMContentLoaded', () => {
    // Browser compatibility
    if (typeof browser === 'undefined') { var browser = chrome; }

    // Buttons in the lean popup
    const openSettingsBtn = document.getElementById('openSettingsBtn');
    const helpBtn = document.getElementById('helpBtn');
    const privacyBtn = document.getElementById('privacyBtn');
    const contactBtn = document.getElementById('contactBtn');
    const donateBtn = document.getElementById('donateBtn');
    
    // Blurr and status elements
    const quickBlurToggle = document.getElementById('quickBlurToggle');
    const quickDeenTabToggle = document.getElementById('quickDeenTabToggle');
    const blockingStatus = document.getElementById('blockingStatus');
    const blurStatus = document.getElementById('blurStatus');
    const blockedCount = document.getElementById('blockedCount');
    const userGuideBtn = document.getElementById('userGuideBtn');

    // Apply saved popup prefs (width/density/theme) for visual consistency
    function applyPopupPrefs(prefs){
        if(!prefs) return;
        document.body.classList.toggle('popup-wide', prefs.popupWidth === 'wide');
        document.body.classList.toggle('popup-narrow', prefs.popupWidth === 'narrow');
        document.body.classList.toggle('popup-compact', prefs.popupDensity === 'compact');
        const dark = (prefs.popupTheme === 'dark') || (prefs.popupTheme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches);
        document.body.classList.toggle('popup-dark', !!dark);
    }
    try { browser.storage.sync.get(['deenTabPopupPrefs'], (res) => applyPopupPrefs(res.deenTabPopupPrefs || {})); } catch {}

    // Apply global appearance (uiStyle/bgStyle/bgCustom/bgImage) similar to settings/DeenTab
    function applyAppearancePreview(settings){
        const body = document.body; if (!body) return;
        const ui = settings.uiStyle || 'classic';
        const bg = settings.bgStyle || 'default';
        const custom = settings.bgCustom || '#174a3c';
        let bgImage = settings.bgImage || '';
        if (bgImage === '__local__') { try { bgImage = localStorage.getItem('deenTabBgImageLocal') || ''; } catch {} }
        body.classList.toggle('ui-liquid', ui === 'liquid');
        body.classList.toggle('ui-classic', ui !== 'liquid');
        ['bg-default','bg-light','bg-dark','bg-pattern','bg-custom','bg-image'].forEach(c => body.classList.remove(c));
        const chosen = (bg === 'light' || bg === 'dark' || bg === 'pattern' || bg === 'custom' || bg === 'image') ? bg : 'default';
        body.classList.add('bg-' + chosen);
        document.documentElement.style.setProperty('--bg-custom', custom);
        if (chosen === 'image' && bgImage) document.documentElement.style.setProperty('--bg-image', `url('${bgImage}')`);
        else document.documentElement.style.removeProperty('--bg-image');
    }
    try {
        browser.storage.sync.get(['settings','deenTabSettings'], (res) => {
            const s = res.settings || {}; const dt = res.deenTabSettings || {};
            const uiStyle = s.uiStyle || dt.uiStyle || 'classic';
            const bgStyle = s.bgStyle || dt.bgStyle || 'default';
            const bgCustom = s.bgCustom || dt.bgCustom || '#174a3c';
            const bgImage = s.bgImage || dt.bgImage || '';
            applyAppearancePreview({ uiStyle, bgStyle, bgCustom, bgImage });
        });
    } catch {}

    function openHelp(){ try { window.open(chrome.runtime.getURL('help.html'), '_blank'); } catch {} }
    function openPrivacy(){ try { window.open(chrome.runtime.getURL('privacy.html'), '_blank'); } catch {} }
    function openExternal(url){ try { window.open(url, '_blank'); } catch {} }
    function openSettingsWindow(){
        try {
            const url = chrome.runtime.getURL('settings.html');
            if (chrome?.windows?.create) chrome.windows.create({ url, type:'popup', width:520, height:740 });
            else window.open(url, '_blank', 'width=520,height=740');
        } catch { window.open('settings.html', '_blank'); }
    }

    if (openSettingsBtn) openSettingsBtn.addEventListener('click', openSettingsWindow);
    if (helpBtn) helpBtn.addEventListener('click', openHelp);
    if (privacyBtn) privacyBtn.addEventListener('click', openPrivacy);
    if (contactBtn) contactBtn.addEventListener('click', () => openExternal('https://alhaq-initiative.org/contact.html'));
    if (donateBtn) donateBtn.addEventListener('click', () => openExternal('https://buy.stripe.com/28E3cwea897i8vkh2l14400'));
    if (userGuideBtn) userGuideBtn.addEventListener('click', () => { try { window.open(chrome.runtime.getURL('guide.html'), '_blank'); } catch {} });
    
    // Load and display current status
    loadPopupStatus();
    
    // Blurr toggle handler
    if (quickBlurToggle) {
        quickBlurToggle.addEventListener('change', toggleBlur);
    }
    
    // DeenTab toggle handler
    if (quickDeenTabToggle) {
        quickDeenTabToggle.addEventListener('change', toggleDeenTab);
    }
    
    // Load Blurr settings and update UI
    function loadPopupStatus() {
        browser.storage.sync.get(['settings', 'blurrSettings'], (res) => {
            const settings = res.settings || {};
            const blurrSettings = res.blurrSettings || { status: false };
            
            // Update blocking status
            if (blockingStatus) {
                const isBlocking = settings.blockHaram || settings.blockSocial;
                blockingStatus.textContent = isBlocking ? 'Active' : 'Inactive';
                blockingStatus.classList.toggle('inactive', !isBlocking);
            }
            
            // Update blur status and toggle
            if (blurStatus && quickBlurToggle) {
                const isBlurring = blurrSettings.status === true;
                blurStatus.textContent = isBlurring ? 'Active' : 'Off';
                blurStatus.classList.toggle('inactive', !isBlurring);
                quickBlurToggle.checked = isBlurring;
            }
            
            // Update DeenTab toggle
            if (quickDeenTabToggle) {
                quickDeenTabToggle.checked = !!settings.quranTabEnabled;
            }
        });
        
        // Load blocked count
        browser.storage.local.get(['blockedToday', 'lastBlockedDate'], (res) => {
            const today = new Date().toDateString();
            let count = 0;
            
            if (res.lastBlockedDate === today) {
                count = res.blockedToday || 0;
            }
            
            if (blockedCount) {
                blockedCount.textContent = count;
            }
        });
    }
    
    // Toggle blur functionality
    function toggleBlur() {
        const enabled = quickBlurToggle.checked;
        
        browser.storage.sync.get(['blurrSettings'], (res) => {
            const blurrSettings = res.blurrSettings || {
                status: false,
                images: true,
                videos: true,
                iframes: true,
                bgImages: true,
                blurAmt: 20,
                grayscale: true,
                ignoredDomains: []
            };
            
            blurrSettings.status = enabled;
            
            browser.storage.sync.set({ blurrSettings }, () => {
                // Update status display
                if (blurStatus) {
                    blurStatus.textContent = enabled ? 'Active' : 'Off';
                    blurStatus.classList.toggle('inactive', !enabled);
                }
                
                // Notify all tabs to update blur
                chrome.tabs.query({}, (tabs) => {
                    tabs.forEach(tab => {
                        chrome.tabs.sendMessage(tab.id, {
                            message: 'updateBlurSettings',
                            settings: blurrSettings
                        }).catch(() => {
                            // Tab may not have content script, ignore
                        });
                    });
                });
            });
        });
    }
    
    // Toggle DeenTab functionality
    function toggleDeenTab() {
        const enabled = quickDeenTabToggle.checked;
        
        browser.storage.sync.get(['settings'], (res) => {
            const settings = res.settings || {};
            settings.quranTabEnabled = enabled;
            
            browser.storage.sync.set({ settings }, () => {
                console.log('DeenTab toggle updated:', enabled);
            });
        });
    }
});
