# Privacy Policy for Deen Shield Extension

**Developer:** Alhaq Digital Services (ADS)  
**Effective Date:** August 10, 2025

## Introduction
Deen Shield is a browser extension developed by Alhaq Digital Services (ADS) to help Muslims maintain halal browsing habits. We are committed to protecting your privacy and ensuring your data is handled according to Islamic values and global privacy standards.

## What Information We Collect
- **Settings and Preferences:** Your blocking choices (haram content, social media, custom keywords) are stored locally in your browser.
- **Password:** If you set a password, it is encrypted and stored locally for extension lock purposes.
- **Custom Keywords:** Any keywords you add for blocking are stored locally.

## What We Do NOT Collect
- We do **not** collect, transmit, or share any personal information, browsing history, website content, analytics, or user data.
- No data is sent to external servers or third parties.
- No tracking, advertising, or analytics are used.

## How We Use Your Data
- All data is stored locally in your browser using secure APIs.
- Data is used only to configure and apply your content blocking preferences.
- Passwords are used only for local authentication and are never transmitted.

## Permissions
- **Storage:** To save your preferences and settings locally.
- **declarativeNetRequest:** To block inappropriate content as per your settings.
- **Host permissions:** To apply blocking rules across websites you visit.

## Data Security
- All sensitive data is encrypted and never stored in plain text.
- Only you have access to your extension data; it cannot be accessed by other websites or extensions.
- Uninstalling the extension removes all stored data.

## Your Rights
- You can modify or delete your settings at any time.
- No account creation or registration is required.
- All source code is open and auditable for transparency.

## Islamic Compliance
- We follow Islamic principles of privacy, trust (Amanah), and ethical technology.
- No deceptive practices, hidden functions, or data collection.
- Our goal is to serve the Ummah and protect your privacy.

## Updates
We may update this policy to reflect changes in our practices or legal requirements. Updates will be posted with a new effective date.

## Contact
For privacy questions or support:
- **Email:** support@alhaq-initiative.org
- **Website:** https://alhaq-initiative.org
- **Contact Page:** https://alhaq-initiative.org/contact.html

---

*Developed by Alhaq Digital Services (ADS) - Islamic Technology Solutions*  
*Committed to helping Muslims maintain halal browsing habits while respecting your privacy.*