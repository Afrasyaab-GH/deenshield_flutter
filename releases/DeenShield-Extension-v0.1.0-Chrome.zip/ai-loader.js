/**
 * AI Loader - Load NSFWJS in MAIN world
 * This script runs in the MAIN world context to load external AI libraries
 * Required because content scripts (ISOLATED world) can't load external scripts
 * 
 * Communication flow:
 * 1. MAIN world (ai-loader.js) loads TensorFlow + NSFWJS libraries
 * 2. MAIN world exposes image analysis via window.postMessage
 * 3. ISOLATED world (ai-content-analyzer.js) sends images via postMessage
 * 4. MAIN world analyzes and posts results back
 */

(function() {
    'use strict';
    
    console.log('🤖 AI Loader: Starting NSFWJS initialization in MAIN world...');
    
    let nsfwModel = null;
    let isModelLoading = false;
    let modelLoadFailed = false;
    
    /**
     * Load NSFWJS model
     */
    async function loadNSFWModel() {
        if (nsfwModel) return nsfwModel;
        if (modelLoadFailed) return null;
        if (isModelLoading) {
            // Wait for existing load
            return new Promise((resolve) => {
                const checkInterval = setInterval(() => {
                    if (nsfwModel || modelLoadFailed) {
                        clearInterval(checkInterval);
                        resolve(nsfwModel);
                    }
                }, 100);
            });
        }

        isModelLoading = true;
        console.log('🤖 Loading NSFWJS model...');

        try {
            // Wait for NSFWJS to be available
            let attempts = 0;
            while (typeof nsfwjs === 'undefined' && attempts < 100) {
                await new Promise(resolve => setTimeout(resolve, 100));
                attempts++;
            }
            
            if (typeof nsfwjs === 'undefined') {
                throw new Error('NSFWJS library not loaded');
            }

            nsfwModel = await nsfwjs.load();
            console.log('✅ NSFWJS model loaded in MAIN world');
            isModelLoading = false;
            
            // Notify ISOLATED world that model is ready
            window.postMessage({ type: 'NSFWJS_MODEL_READY' }, '*');
            
            return nsfwModel;
        } catch (error) {
            console.error('❌ Failed to load NSFWJS model:', error);
            modelLoadFailed = true;
            isModelLoading = false;
            window.postMessage({ type: 'NSFWJS_MODEL_FAILED', error: error.message }, '*');
            return null;
        }
    }
    
    /**
     * Analyze image from data URL
     */
    async function analyzeImageDataURL(dataURL, requestId) {
        try {
            const model = await loadNSFWModel();
            if (!model) {
                throw new Error('Model not available');
            }

            // Create image element
            const img = new Image();
            img.crossOrigin = 'anonymous';
            
            await new Promise((resolve, reject) => {
                img.onload = resolve;
                img.onerror = reject;
                img.src = dataURL;
            });

            // Classify
            const predictions = await model.classify(img);
            
            // Send results back
            window.postMessage({
                type: 'NSFWJS_ANALYSIS_RESULT',
                requestId: requestId,
                predictions: predictions
            }, '*');
            
        } catch (error) {
            console.error('❌ Image analysis error:', error);
            window.postMessage({
                type: 'NSFWJS_ANALYSIS_ERROR',
                requestId: requestId,
                error: error.message
            }, '*');
        }
    }
    
    // Listen for analysis requests from ISOLATED world
    window.addEventListener('message', (event) => {
        if (event.source !== window) return;
        
        if (event.data.type === 'NSFWJS_ANALYZE_REQUEST') {
            analyzeImageDataURL(event.data.dataURL, event.data.requestId);
        }
    });
    
    // Load TensorFlow.js
    const tfScript = document.createElement('script');
    tfScript.src = 'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.11.0/dist/tf.min.js';
    tfScript.crossOrigin = 'anonymous';
    tfScript.onload = () => {
        console.log('✅ TensorFlow.js loaded in MAIN world');
        
        // Load NSFWJS after TensorFlow
        const nsfwScript = document.createElement('script');
        nsfwScript.src = 'https://cdn.jsdelivr.net/npm/nsfwjs@2.4.2/dist/nsfwjs.min.js';
        nsfwScript.crossOrigin = 'anonymous';
        nsfwScript.onload = () => {
            console.log('✅ NSFWJS library loaded in MAIN world');
            // Start loading the model
            loadNSFWModel();
        };
        nsfwScript.onerror = (error) => {
            console.error('❌ Failed to load NSFWJS:', error);
            window.postMessage({ type: 'NSFWJS_LOAD_FAILED' }, '*');
        };
        document.head.appendChild(nsfwScript);
    };
    tfScript.onerror = (error) => {
        console.error('❌ Failed to load TensorFlow.js:', error);
        window.postMessage({ type: 'NSFWJS_LOAD_FAILED' }, '*');
    };
    document.head.appendChild(tfScript);
})();
