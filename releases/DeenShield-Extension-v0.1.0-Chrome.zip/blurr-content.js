/**
 * @name blurr-content.js
 * @title Content Blur for DeenShield Extension
 * @description Blurs images, videos, iframes, and background images on web pages
 * based on user preferences. Integrates the DeenShield-Blurr feature into DeenShield.
 */

// Browser compatibility
if (typeof browser === "undefined") {
    var browser = chrome;
}

// Global settings for blur
let blurrSettings = null;

/**
 * Initialize the blur feature
 */
function initBlurr() {
    loadBlurrSettings().then(() => {
        if (blurrSettings && blurrSettings.status === true && !isDomainIgnored()) {
            applyBlur();
        }
        setupMessageListeners();
    });
}

/**
 * Load blur settings from storage
 */
function loadBlurrSettings() {
    return new Promise((resolve) => {
        browser.storage.sync.get(['blurrSettings'], (storage) => {
            blurrSettings = storage.blurrSettings || {
                status: false,
                images: true,
                videos: true,
                iframes: true,
                bgImages: true,
                blurAmt: 20,
                grayscale: true,
                ignoredDomains: []
            };
            resolve();
        });
    });
}

/**
 * Check if current domain is in the ignored list
 */
function isDomainIgnored() {
    if (!blurrSettings || !Array.isArray(blurrSettings.ignoredDomains)) {
        return false;
    }
    const currentDomain = window.location.hostname;
    return blurrSettings.ignoredDomains.indexOf(currentDomain) >= 0;
}

/**
 * Apply blur CSS to the page
 */
function applyBlur() {
    removeBlur(); // Remove existing blur first
    
    const style = document.createElement("style");
    style.type = 'text/css';
    style.rel = 'stylesheet';
    style.id = "deenshield-blurr";
    style.innerHTML = generateBlurCSS();
    style.async = false;
    
    // Append to documentElement (works better for some sites)
    if (document.documentElement) {
        document.documentElement.appendChild(style);
    } else {
        // Fallback to head if documentElement not ready
        document.addEventListener('DOMContentLoaded', () => {
            if (document.head) {
                document.head.appendChild(style);
            }
        });
    }
}

/**
 * Remove blur CSS from the page
 */
function removeBlur() {
    const existingStyle = document.getElementById("deenshield-blurr");
    if (existingStyle && existingStyle.parentNode) {
        existingStyle.parentNode.removeChild(existingStyle);
    }
}

/**
 * Generate CSS rules based on blur settings
 */
function generateBlurCSS() {
    let cssRules = "";
    const blurAmt = `blur(${blurrSettings.blurAmt}px) `;
    const grayscale = blurrSettings.grayscale === true ? "grayscale(100%) " : "";
    const filter = blurAmt + grayscale;

    if (blurrSettings.images === true) {
        cssRules += `img { filter: ${filter}!important; } `;
    }
    
    if (blurrSettings.videos === true) {
        cssRules += `video { filter: ${filter}!important; } `;
    }
    
    if (blurrSettings.iframes === true) {
        cssRules += `iframe { filter: ${filter}!important; } `;
    }
    
    if (blurrSettings.bgImages === true) {
        cssRules += `div[style*='url'], span[style*='url'], a[style*='url'], i[style*='url'], section[style*='url'] { filter: ${filter}!important; }`;
    }

    return cssRules;
}

/**
 * Update blur settings and reapply
 */
function updateBlur(newSettings) {
    blurrSettings = newSettings;
    removeBlur();
    
    if (blurrSettings && blurrSettings.status === true && !isDomainIgnored()) {
        applyBlur();
    }
}

/**
 * Toggle blur status (on/off)
 */
function toggleBlurStatus() {
    if (!blurrSettings) return;
    
    blurrSettings.status = !blurrSettings.status;
    browser.storage.sync.set({ blurrSettings });
    
    removeBlur();
    if (blurrSettings.status === true && !isDomainIgnored()) {
        applyBlur();
    }
}

/**
 * Toggle blur for selected element under cursor
 */
function toggleSelectedElement() {
    const hoverElements = document.querySelectorAll(":hover");
    let imageFound = false;
    let firstImageCSSText = null;

    hoverElements.forEach((element) => {
        if (isBlurrableElement(element)) {
            if (!imageFound) {
                // First image found - determine what to do
                const currentFilter = element.style.filter;
                
                if (blurrSettings.status === true && currentFilter === "") {
                    // Default blur is on, no override - add unblur
                    element.style.cssText += ';filter: blur(0px) !important;';
                } else if (blurrSettings.status === false && currentFilter === "") {
                    // Default blur is off, no override - add blur
                    const blurAmt = `blur(${blurrSettings.blurAmt}px) `;
                    const grayscale = blurrSettings.grayscale ? "grayscale(100%) " : "";
                    element.style.cssText += `;filter: ${blurAmt}${grayscale}!important;`;
                } else if (currentFilter.includes("blur(0px)")) {
                    // Has unblur override - add blur
                    const blurAmt = `blur(${blurrSettings.blurAmt}px) `;
                    const grayscale = blurrSettings.grayscale ? "grayscale(100%) " : "";
                    element.style.cssText += `;filter: ${blurAmt}${grayscale}!important;`;
                } else {
                    // Has blur override - remove it
                    element.style.cssText += ';filter: blur(0px) !important;';
                }
                
                firstImageCSSText = element.style.cssText;
                imageFound = true;
            } else {
                // Apply same filter to other images under cursor
                const filterMatch = firstImageCSSText.match(/(filter.*$)/);
                if (filterMatch) {
                    element.style.cssText += ';' + filterMatch[0];
                }
            }
        }
    });
}

/**
 * Check if element is blurrable (image, video, iframe, or has background image)
 */
function isBlurrableElement(element) {
    if (element.nodeName === 'IMG' || element.nodeName === 'VIDEO' || element.nodeName === 'IFRAME') {
        return true;
    }
    
    if (element.style && element.style.cssText) {
        return /url\(([^()]+)\)/.test(element.style.cssText);
    }
    
    return false;
}

/**
 * Setup message listeners for communication with popup and background
 */
function setupMessageListeners() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.message === 'reverse_status' || request.message === 'toggleBlurStatus') {
            toggleBlurStatus();
        } else if (request.message === 'toggle_selected' || request.message === 'toggleSelectedBlur') {
            toggleSelectedElement();
        } else if (request.message === 'updateBlurSettings') {
            updateBlur(request.settings);
        } else if (request.message && typeof request.message === 'object' && request.message.type === 'blurrSettings') {
            updateBlur(request.message);
        }
        
        return true; // Keep message channel open for async responses
    });
}

/**
 * Keyboard shortcuts setup
 * Alt+L: Toggle blur on/off
 * Alt+K: Toggle blur for selected element
 */
function setupKeyboardShortcuts() {
    document.addEventListener('keydown', (event) => {
        // Alt+L: Toggle blur status
        if (event.altKey && event.key.toLowerCase() === 'l') {
            event.preventDefault();
            toggleBlurStatus();
        }
        
        // Alt+K: Toggle selected element blur
        if (event.altKey && event.key.toLowerCase() === 'k') {
            event.preventDefault();
            toggleSelectedElement();
        }
    });
}

// Initialize on load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        initBlurr();
        setupKeyboardShortcuts();
    });
} else {
    initBlurr();
    setupKeyboardShortcuts();
}
